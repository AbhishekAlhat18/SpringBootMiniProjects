package com.abhishek.springboot.mvccrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvccrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
