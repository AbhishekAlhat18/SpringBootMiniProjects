package com.abhishek.mvc.ValidationDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
