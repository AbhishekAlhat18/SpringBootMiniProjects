package com.abhishek.springdemo.mvc.Validationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
